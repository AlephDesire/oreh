import { useState } from 'react'
import axios from 'axios'

function App() {
  const [messages, setMessages] = useState([
    { role: 'assistant', content: "Hi, I'm Oreshka. How can I assist you in the crypto world today?" }
  ])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)

  const sendMessage = async () => {
    if (!input.trim()) return

    const userMessage = { role: 'user', content: input }
    setMessages(prev => [...prev, userMessage])
    setInput('')
    setLoading(true)

    try {
      const response = await axios.post(
        'https://agent-l7qo5btjtkjylacgfr4toppo-ol6fi.ondigitalocean.app/api/v1/chat/completions',
        {
          messages: [...messages, userMessage],
          stream: false
        },
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer QDdn6Ks0Tma0LJOeh3bqt764p5eYQ3gk'
          }
        }
      )

      const reply = response.data.choices[0].message
      setMessages(prev => [...prev, reply])
    } catch (error) {
      console.error(error)
      setMessages(prev => [...prev, { role: 'assistant', content: "Something went wrong. Try again!" }])
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white flex flex-col items-center p-4">
      <h1 className="text-3xl font-bold mb-4">Oreshka - Crypto Assistant</h1>

      <div className="w-full max-w-2xl bg-gray-800 p-4 rounded-lg shadow-lg flex-1 overflow-y-auto">
        {messages.map((msg, i) => (
          <div key={i} className={`mb-3 ${msg.role === 'user' ? 'text-right' : 'text-left'}`}>
            <span className={`inline-block p-2 rounded-lg ${msg.role === 'user' ? 'bg-blue-600' : 'bg-gray-700'}`}>
              {msg.content}
            </span>
          </div>
        ))}
        {loading && <div className="text-left text-gray-400">Oreshka is typing...</div>}
      </div>

      <div className="w-full max-w-2xl mt-4 flex gap-2">
        <input
          className="flex-1 p-2 rounded bg-gray-700 border border-gray-600 text-white"
          type="text"
          placeholder="Type your message..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
        />
        <button
          onClick={sendMessage}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded"
        >
          Send
        </button>
      </div>
    </div>
  )
}

export default App
